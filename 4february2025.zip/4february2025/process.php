<?php
session_start();
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $username = $_POST["username"];

    $sql = "INSERT INTO users (firstname, lastname, username) VALUES (?, ?, ?)";
    $stm = $con->prepare($sql);

    if ($stm) {
        $stm->bind_param("sss", $firstname, $lastname, $username);

        if ($stm->execute()) {
            $user_id = $stm->insert_id;
            $_SESSION["user_id"] = $user_id;
            $_SESSION["firstname"] = $firstname;
            $_SESSION["username"] = $username;

            $stm->close();
            header("Location: Landing.php");
            exit();
        } else {
            echo "Error executing query: " . $stm->error;
        }
    } else {
        echo "Error preparing statement: " . $con->error;
    }
}
?>
