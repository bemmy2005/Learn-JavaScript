<?php
session_start();
include "db.php";
//$user_id =$_SESSION["user_id"];
if(!isset($_SESSION["user_id"])){
	header("Location: index.php");
	exit();
}
$user_id =$_SESSION["user_id"];

	if($_SERVER["REQUEST_METHOD"]=="POST"){
			$telephone =$_POST["telephone"];
			$email =$_POST["email"];
			$bio = $_POST["bio"];

		$stmt=$con->prepare("INSERT INTO profiles (user_id,telephone,email,bio) values (?,?,?,?) ON DUPLICATE KEY UPDATE telephone=?,email=?,bio=?");

		$stmt->bind_param("issssss",$user_id,$telephone,$email,$bio,$telephone,$email,$bio);
		$stmt->execute();
		$stmt->close();

	}

	$stmt =$con->prepare("SELECT telephone,email,bio FROM profiles WHERE user_id =?");
	$stmt->bind_param("i",$user_id);
	$stmt->execute();
	$stmt->bind_result($telephone,$email,$bio);
	//$stmt->bind_result($email);
	//$stmt->bind_result($bio);
	$stmt->fetch();
	$stmt->close();

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home</title>
</head>
<body>
	<center>
	<header>
		<nav>
			<a href="#">Welecome, <?php echo htmlspecialchars($_SESSION["firstname"]); ?></a> | 

			<a href="index.php">Home</a> |
			<a href="profile.php">Profile</a> |
			<a href="Landing.php">Welcome</a> |
			<a href="logout.php">Logout</a>
		</nav>
	</header>
	<main>
		<h2>Information from Profile table</h2>
		<form action="profile.php" method="post">
			<input type="text" name="telephone" placeholder="<?php echo htmlspecialchars($telephone); ?>" required > <br>
			<br>
			<input type="text" name="email" placeholder="<?php echo htmlspecialchars($email); ?>" required><br>
			<br>
			<textarea name="bio" required> <?php echo htmlspecialchars($bio); ?>
			</textarea><br>
			<br>
			<input type="submit" name="Submit">

		</form>
	</main>
<footer>&copy; &reg;</footer>
</center>
</body>
</html>