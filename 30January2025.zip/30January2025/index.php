<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home page</title>
</head>
<body>
	<header>
		<center>
		<nav>
			<a href="index.php">Home</a> |
			<a href="form.php">Form</a> |
			<a href="table.php">Table</a> |
		</nav>
	</center>
	</header>
	<main>
		<center>
		<img src="1684324546463.jpg" width="600" height="400" alt="The image will be here">
	</center>
	</main>
	<footer>
		<center>@copy&</center>
	</footer>
</body>
</html>