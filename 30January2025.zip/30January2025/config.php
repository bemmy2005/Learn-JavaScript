<?php
$servername ="localhost";
$uname ="root";
$pwd ="root";//""
$dbname = "schools_db";

$conn= new mysqli($servername, $uname,$pwd,$dbname);

if($conn -> connect_error){
	die("Connection failed". $conn ->connect_error );
}

?>