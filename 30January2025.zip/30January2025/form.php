<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home page</title>
</head>
<body>
	<header>
		<center>
		<nav>
			<a href="index.php">Home</a> |
			<a href="form.php">Form</a> |
			<a href="table.php">Table</a> |
		</nav>
	</center>
	</header>
	<main>
		<center>
		<h1>Form Example</h1>
	<form action="insert.php" method="POST">
		<table>
	<tr> 
		<td><label for="id" >ID:</label></td>
		<td><input type="" id="id" name="id"> <br><br></td>
	</tr>
		<tr>
			<td><label for="fname" >First name:</label></td>
			<td><input type="" id="fname" name="fname"> <br><br></td>
		</tr>
			
		<tr><td><label for="lname" >Last name:</label></td>
		<td><input type="" id="lname" name="lname"> <br><br></td></tr>
		
		<tr>
			<td><label for="gender" >Gender:</label></td>
			<td><input type="" id="gender" name="gender"> <br><br></td>
		</tr>	
			<tr>
				<td><label for="DOB" >DOB:</label></td>
				<td><input type="Date" id="DOB" name="DOB"> <br><br></td>
			</tr>
		<tr>
		<td><label for="Age" >Age:</label></td>
		<td> <input type="" id="Age" name="Age"> <br><br></td>
		</tr>
			
		<tr>
			<td><label for="RegNumber" >Reg Number:</label></td>
			<td><input type="" id="RegNumber" name="RegNumber"> <br><br></td>
		</tr>

		<tr>
			<td><label for="Province" >Province:</label></td>
			<td><input type="" id="Province" name="Province"> <br><br></td>
		</tr>
		
		<tr>
			<td><label for="District" >District:</label></td>
			<td><input type="" id="District" name="District"> <br><br></td>
		</tr>	
			
		<tr>
			<td><label for="Sector" >Sector:</label></td>
			<td><input type="" id="Sector" name="Sector"> <br><br></td>
		</tr>

		<tr>
			<td><label for="Sector" >Cell:</label></td>
			<td><input type="" id="Cell" name="Cell"> <br><br></td>
		</tr>
			
		
		<tr>
			<td><label for="Sector" >Village:</label></td>
			<td><input type="" id="Village" name="Village"> <br><br></td>
		</tr>
			
		<tr>
			<td><label for="PhoneNumber" >Phone Number:</label></td>
			<td><input type="" id="PhoneNumber" name="PhoneNumber"> <br><br></td></tr>
			
		<td><button type="submit">Submit</button></td>	
	</table>
	</form>
	</center>
	</main>
	<footer>
		<center>@copy&</center>
	</footer>
</body>
</html>