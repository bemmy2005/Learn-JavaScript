<?php
	include 'config.php';

	if($_SERVER['REQUEST_METHOD'] =="POST"){
			//variables
		$id=$_POST['id'];
		$first_name = $_POST['fname'];
    	$last_name = $_POST['lname'];
    	$gender = $_POST['gender'];
    	$dob = $_POST['DOB'];
    	$age = $_POST['Age'];
    	$reg_number = $_POST['RegNumber'];
    	$province = $_POST['Province'];
    	$district = $_POST['District'];
    	$sector = $_POST['Sector'];
    	$cell = $_POST['Cell'];
    	$village = $_POST['Village'];
    	$phone_number = $_POST['PhoneNumber'];
    	//sql query
    	$sql = "INSERT INTO students(id, first_name, last_name, gender, dob, age, reg_number, province, district, sector, cell, village, phone_number) 
    	VALUES
    	('$id', '$first_name', '$last_name', '$gender', '$dob', '$age', '$reg_number', '$province', '$district', '$sector', '$cell', '$village', '$phone_number')";

    	if($conn -> query($sql) == TRUE ){
    		echo "Data Inserted Successifully!";
    	}else{
    		echo "Error: ".$sql."<br>" .$conn -> error;
    		    	}
    		    	$conn -> close();

	}
?>