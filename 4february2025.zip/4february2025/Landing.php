<?php
session_start();
if(!isset($_SESSION["user_id"])){
	header("Location:index.php");
	exit();

}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Landing page</title>
</head>
<body>
<body>
	<center>
	<header>
		<nav>
			<a href="#">Welecome, <?php echo htmlspecialchars($_SESSION["firstname"]); ?></a> | 
			<a href="index.php">Home</a> |
			<a href="profile.php">Profile</a> |
			<a href="Landing.php">Welcome</a> |
			<a href="logout.php">Logout</a>
		</nav>
	</header>
	<main>
		<h2>Wlecome, <?php echo htmlspecialchars($_SESSION["firstname"]); ?>!</h2>

	</main>
	<footer></footer>
</body>
</html>