<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Data from Database</title>
</head>
<body>
	<header>
		<center>
		<nav>
			<a href="index.php">Home</a> |
			<a href="form.php">Form</a> |
			<a href="table.php">Table</a> |
		</nav>
	</center>
	</header>
	<main>
		<center>
		<table border="1">
			<tr>
				<th>ID</th>
				<th>First name</th>
				<th>Last name</th>
				<th>Gender</th>
				<th>DOB</th>
				<th>Age</th>
				<th>Reg Number</th>
				<th>Province</th>
				<th>District</th>
				<th>Sector</th>
				<th>Cell</th>
				<th>Village</th>
				<th>Phone Number</th>
			</tr>
			//we add php to get data from the database 
			<?php
				include 'config.php';
				$sql ="SELECT * FROM students";

				$results = $conn -> query($sql);

				if($results->num_rows>0){
					while($row =$results ->fetch_assoc()){
						echo "<tr>
							<td>{$row['id']}</td>
							<td>{$row['first_name']}</td>
							<td>{$row['last_name']}</td>
							<td>{$row['gender']}</td>
							<td>{$row['dob']}</td>
							<td>{$row['age']}</td>
							<td>{$row['reg_number']}</td>
							<td>{$row['province']}</td>
							<td>{$row['district']}</td>
							<td>{$row['sector']}</td>
							<td>{$row['cell']}</td>
							<td>{$row['village']}</td>
							<td>{$row['phone_number']}</td>
					</tr>";
					}
				}else{
					echo "<tr><td colspan='13'>No records found</td></tr>";
				}
				$conn->close();
			?>
		</table>
	</center>
	</main>
	<footer>
		<center>@copy&</center>
	</footer>
</body>
</html>