<?php
	$server="localhost";
	$uname ="root";
	$pwd ="root";
	$dbname = "session_examplee";

	$con= new mysqli($server,$uname,$pwd,$dbname);

	if($con->connect_error){
	 die("Connection fialed" .$con->connect_error);
	}




?>