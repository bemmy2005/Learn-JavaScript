CREATE DATABASE session_examplee;

use session_examplee;

create table users(
id int auto_increment primary key,
firstname varchar(50) not null,
lastname varchar(50) not null,
username varchar(50) not null 
);

create table profiles(
id int auto_increment primary key,
user_id int not null,
email varchar(50) not null,
telephone varchar(50) not null,
bio text,
foreign key (user_id) references users(id) on delete cascade
);