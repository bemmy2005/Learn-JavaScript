<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home</title>
</head>
<body>
	<center>
	<header>
		<nav>
			<a href="index.php">Home</a> |
			<a href="profile.php">Profile</a> |
			<a href="Landing.php">Welcome</a> |
			<a href="logout.php">Logout</a>
		</nav>
	</header>
	<main>
		<h2>Information</h2>
		<form action="process.php" method="post">
			<input type="text" name="firstname" placeholder="Enter your first name" required > <br>
			<br>
			<input type="text" name="lastname" placeholder="Enter your last name" required><br>
			<br>
			<input type="text" name="username" placeholder="Enter your username" required><br>
			<br>
			<input type="submit" name="Submit">

		</form>
	</main>
<footer>&copy; &reg;</footer>
</center>
</body>
</html>